
from django.shortcuts import render

def index(request):
    return render(request, 'myapp/index.html')

def about(request):
    return render(request, 'myapp/about.html')

def blog(request):
    return render(request, 'myapp/blog.html')

def causes(request):
    return render(request, 'myapp/causes.html')

def contact(request):
    return render(request, 'myapp/contact.html')

def single(request):
    return render(request, 'myapp/single.html')
